<div id="wrapperApplication" class="wrapper"></div>
<!--load before somthing not yet done -->
<div id="holdpageloadhide" style="display:block;text-align: center;position: fixed;top: 0; left: 0;width: 100%; height: 100%;background: rgba(142, 159, 167, 0.8);z-index: 9999;">
	<i class="fa fa-circle-o-notch fa-spin" style="font-size: 50px;color: #fff;position: absolute; top: 45%;left: 45%"></i>
</div>
<!-- template section starts -->
<script type="text/x-kendo-template" id="layout">
	<!-- <div id="menu" class="menu"></div> -->
	<div id="content"></div>
</script>
<script type="text/x-kendo-template" id="blank-tmpl">
</script>

<script id="multiTaskList-row-template" type="text/x-kendo-template">
    <li >
    	<a data-toggle="collapse" data-target=".navbar-collapse.in" href="\#/#=url#">
    		<span >#=name#</span>
    		<span title="Remove" class="multiTaskList glyphicons remove_2 pull-right" data-bind="click: removeLink">
    			<i></i>
    		</span>
    	</a>
    </li>	
</script>
<style >
	.home .bg-green{
		background: green;
		width: 100%;
		text-align: center;
		position: relative;
	}
	.height250{
		height: 280px;
	}
	.height100{
		height: 100px;
	}
	.no-padding{
		padding: 0;
	}
	.no-paddingLeft{
		padding-left: 0;
		padding-right: 2px;
	}
	.nopadding-right{
		padding-right: 0
	}
	.nopadding-left{
		padding-left: 0
	}
	.paddingLeftRigth{
		padding: 0 2px;
	}
	.paddingTopBottom{
		padding: 2px 0;
	}
	.top-left{
		border-radius: 10px 0 0 0;
	}
	.top-rigth{
		border-radius: 0 10px 0 0;
	}
	.bottom-left{
		border-radius: 0 0 0 10px ;
	}
	.bottom-rigth{
		border-radius: 0 0 10px 0;
	}
	.paddingLeft{
		padding-left: 2px;
	}
	.bg-green.height250.top-left img{
		width: 183px;
	    margin-top: 50px;
	    float: left;
	    margin-left: 70px;
	}
	.bg-green.height250 img{
		width: 183px;
	    margin-top: 50px;
	    float: left;
	    margin-left: 57px;
	}
	.bg-green.height250.top-rigth img{
		width: 183px;
	    margin-top: 50px;
	    float: left;
	    margin-left: 57px;
	}
</style>
<!-- ***************************
*	Water Section      	  *
**************************** -->
<script id="Index" type="text/x-kendo-template">
	<div class="container">
		<div class="row home">
			<div class="span12">
				<div class="row">
					<div class="span6 nopadding-right">
						<div class="bg-green height250 top-left">
							 <img src="<?php echo base_url();?>assets/spa/icon/pos-01.png" >
							Point of Sale
						</div>
					</div>
					<div class="span6" >
						<div class="row">
							<div class="span6 paddingLeftRigth">
								<div class="bg-green height250">
									<img src="<?php echo base_url();?>assets/spa/icon/scan-01.png" >
									Session
								</div>
							</div>
							<div class="span6 nopadding-left">
								<div class="bg-green height250 top-rigth">
									<img src="<?php echo base_url();?>assets/spa/icon/calander-01.png" >
									Book
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="span12">
				<div class="row paddingTopBottom">
					<div class="span6 nopadding-right">
						<div class="bg-green height250">
							Point of Sale
						</div>
					</div>
					<div class="span6" >
						<div class="row">
							<div class="span6 paddingLeftRigth">
								<div class="bg-green height250">
									Session
								</div>
							</div>
							<div class="span6 nopadding-left">
								<div class="bg-green height250">
									Book
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="span12">
				<div class="row">
					<div class="span6" >
						<div class="row">
							<div class="span3 nopadding-right">
								<div class="bg-green height100 bottom-left">
									1
								</div>
							</div>
							<div class="span3 paddingLeftRigth">
								<div class="bg-green height100">
									2
								</div>
							</div>
							<div class="span3 no-paddingLeft">
								<div class="bg-green height100">
									3
								</div>
							</div>
							<div class="span3 no-padding">
								<div class="bg-green height100">
									4
								</div>
							</div>
						</div>
					</div>
					<div class="span6 paddingLeft">
						<div class="bg-green height100 bottom-rigth">
							Report
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</script>                      